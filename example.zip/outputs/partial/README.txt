KitClear allocation packet
Supported limits: 2,000 components; 200 products; 100 components/BOM; 100 orders. Stock/reservations <=1,000,000; BOM units <=10,000; order units <=100,000; priority 1–10,000. IDs 1–64 printable characters.
Algorithm: kitclear-1.1
Input SHA256: a50043ca31586576d1055a94e18a972cbb66bf3fcc6f451ff54aa095a54b9348
Synthetic: True
Explicit descending-priority allocation with input-order ties; not a global optimum.
Single-level integer BOMs and one stock location only; source inventory accuracy is not established.
No substitutions, product configuration, forecasts, purchasing, or physical assembly instructions.
Reservations are unavailable stock; they are not assigned to these orders. Additional components are a mathematical shortage, not a purchase recommendation. CSV formula-like IDs are apostrophe-escaped; JSON preserves exact IDs.

KitClear inventory planning example — synthetic packet

SYNTHETIC. No customer data. Neutral inventory names (board, case, cable, sensor-kit, board-pair).

This zip is a free worked example for the existing $49 one-time KitClear Offline product.
It is not the paid tool. It cannot read your files. There is no upload and no input tracking.

Source: inputs/example.json (partial_fulfillment true as stored). Whole-order numbers use the
same snapshot with partial_fulfillment set to false.

Outputs (four files per mode, from the accepted engine):
  outputs/partial/allocation.json orders.csv materials.csv README.txt
  outputs/whole/allocation.json orders.csv materials.csv README.txt

Expected fills on this fixture: partial 6, 2, 0 for ORDER-A, ORDER-B, ORDER-C.
Whole-order fills 6, 0, 0. Two reserved boards are never assigned to these orders.

Limits: greedy descending integer priority then input-order ties; one-level integer BOMs;
one stock location; not globally optimal. No forecasts, purchasing, dates, substitutions,
or physical assembly or safety guidance. Shortages are mathematical review information,
not purchase orders.

SHA-256 of each member (except this README’s companion list) is in MANIFEST.sha256.

Product: https://ustechautomations.com/feeds/kitclear
Gumroad $49 one-time: https://ustechautomations.gumroad.com/l/kitclear-offline
